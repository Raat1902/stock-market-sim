#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <iomanip>

using namespace std;

struct Stock {
    string name;
    double price;
};

void simulateDay(vector<Stock>& stocks) {
    for (auto& stock : stocks) {
        double changePercent = (rand() % 2001 - 1000) / 100.0; // -10% to +10%
        stock.price *= (1 + changePercent / 100.0);
        if (stock.price < 1.0) stock.price = 1.0;
    }
}

void showMarket(const vector<Stock>& stocks) {
    cout << fixed << setprecision(2);
    cout << "\n--- Current Market Prices ---\n";
    for (size_t i = 0; i < stocks.size(); ++i) {
        cout << i + 1 << ". " << stocks[i].name << " - $" << stocks[i].price << endl;
    }
}

int main() {
    srand(static_cast<unsigned int>(time(0)));

    vector<Stock> stocks = {
        {"TechCorp", 100.0},
        {"HealthInc", 80.0},
        {"FinBank", 60.0},
        {"GreenEnergy", 90.0}
    };

    double cash = 1000.0;
    vector<int> shares(stocks.size(), 0);

    int choice;
    while (true) {
        showMarket(stocks);
        cout << "\nCash: $" << cash << "\n";
        cout << "Your portfolio:\n";
        for (size_t i = 0; i < stocks.size(); ++i) {
            cout << stocks[i].name << ": " << shares[i] << " shares\n";
        }

        cout << "\n1. Buy\n2. Sell\n3. Next Day\n4. Exit\nChoice: ";
        cin >> choice;

        if (choice == 1) {
            int stockIndex, amount;
            cout << "Enter stock number to buy: ";
            cin >> stockIndex;
            cout << "Enter number of shares: ";
            cin >> amount;

            --stockIndex;
            double cost = amount * stocks[stockIndex].price;
            if (stockIndex >= 0 && stockIndex < (int)stocks.size() && cost <= cash) {
                cash -= cost;
                shares[stockIndex] += amount;
                cout << "Bought " << amount << " shares of " << stocks[stockIndex].name << ".\n";
            } else {
                cout << "Invalid transaction.\n";
            }
        } else if (choice == 2) {
            int stockIndex, amount;
            cout << "Enter stock number to sell: ";
            cin >> stockIndex;
            cout << "Enter number of shares: ";
            cin >> amount;

            --stockIndex;
            if (stockIndex >= 0 && stockIndex < (int)stocks.size() && amount <= shares[stockIndex]) {
                double revenue = amount * stocks[stockIndex].price;
                cash += revenue;
                shares[stockIndex] -= amount;
                cout << "Sold " << amount << " shares of " << stocks[stockIndex].name << ".\n";
            } else {
                cout << "Invalid transaction.\n";
            }
        } else if (choice == 3) {
            simulateDay(stocks);
            cout << "\nA new trading day has begun...\n";
        } else if (choice == 4) {
            break;
        } else {
            cout << "Invalid choice.\n";
        }
    }

    cout << "\nFinal portfolio value: $" << cash << "\n";
    for (size_t i = 0; i < stocks.size(); ++i) {
        cash += shares[i] * stocks[i].price;
    }
    cout << "Total value (cash + stocks): $" << cash << "\n";

    return 0;
}
